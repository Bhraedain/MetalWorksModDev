package net.mcreator.meatalworks_001;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

@Elementsmeatalworks_001.ModElement.Tag
public class MCreatorLMPick extends Elementsmeatalworks_001.ModElement {
	@ObjectHolder("meatalworks_001:lmpick")
	public static final Item block = null;

	public MCreatorLMPick(Elementsmeatalworks_001 instance) {
		super(instance, 6);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 250;
			}

			public float getEfficiency() {
				return 6f;
			}

			public float getAttackDamage() {
				return 2f;
			}

			public int getHarvestLevel() {
				return 3;
			}

			public int getEnchantability() {
				return 2;
			}

			public Ingredient getRepairMaterial() {
				return null;
			}
		}, 1, -3F, new Item.Properties().group(MCreatorMeatalWorks.tab)) {
		}.setRegistryName("lmpick"));
	}
}
