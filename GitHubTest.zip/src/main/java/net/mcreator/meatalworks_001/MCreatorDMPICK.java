package net.mcreator.meatalworks_001;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

@Elementsmeatalworks_001.ModElement.Tag
public class MCreatorDMPICK extends Elementsmeatalworks_001.ModElement {
	@ObjectHolder("meatalworks_001:dmpick")
	public static final Item block = null;

	public MCreatorDMPICK(Elementsmeatalworks_001 instance) {
		super(instance, 12);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 225;
			}

			public float getEfficiency() {
				return 10f;
			}

			public float getAttackDamage() {
				return 2f;
			}

			public int getHarvestLevel() {
				return 10;
			}

			public int getEnchantability() {
				return 2;
			}

			public Ingredient getRepairMaterial() {
				return null;
			}
		}, 1, -3F, new Item.Properties().group(MCreatorMeatalWorks.tab)) {
		}.setRegistryName("dmpick"));
	}
}
